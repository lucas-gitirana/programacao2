/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package projetojpa;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author 10816533962
 */
public class ProjetoJPA {

    /**
     * @param args the command line arguments
     */
    /*public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("ProjetoJPAPU");
        EntityManager em = emf.createEntityManager();
        
        try {
            em.getTransaction().begin();
            
            TeachingStaff tf = new TeachingStaff(1l, "Lucas", "Professor", "Programação");
            em.persist(tf);
            
            NonTeachingStaff nt = new NonTeachingStaff(2l, "Jãozin", "Merenda");
            em.persist(nt);
            
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
        }
    }*/
    
}
