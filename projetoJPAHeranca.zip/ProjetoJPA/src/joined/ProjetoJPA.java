/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package joined;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import table_per_class.Fisica;
import table_per_class.Juridica;

/**
 *
 * @author 10816533962
 */
public class ProjetoJPA {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("ProjetoJPAPU");
        EntityManager em = emf.createEntityManager();
        
        /*try {
            em.getTransaction().begin();
            
            TeachingStaffJoin tf = new TeachingStaffJoin(1l, "Lucas", "Professor", "Programação");
            em.persist(tf);
            
            NonTeachingStaffJoin nt = new NonTeachingStaffJoin(2l, "Jãozin", "Merenda");
            em.persist(nt);
            
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
        }*/
        
        try {
            em.getTransaction().begin();
            
            Fisica f = new Fisica(1l, "Lucas", "451.632.365-98");
            em.persist(f);
            
            Juridica j = new Juridica(2l, "Amazon", "4555.6566.99999-45");
            em.persist(j);
            
            em.getTransaction().commit();
        } catch (Exception e) {
        }
    }
    
}
