/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package joined;

import java.io.Serializable;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrimaryKeyJoinColumn;

/**
 *
 * @author 10816533962
 */
@Entity
@PrimaryKeyJoinColumn(referencedColumnName = "id")
public class NonTeachingStaffJoin extends StaffJoined implements Serializable {

    private static final long serialVersionUID = 1L;
    private String areaexpertise;

    public NonTeachingStaffJoin() {
    }

    public NonTeachingStaffJoin(Long id, String name, String areaexpertise) {
        super(id, name);
        this.areaexpertise = areaexpertise;
    }

    public String getAreaexpertise() {
        return areaexpertise;
    }

    public void setAreaexpertise(String areaexpertise) {
        this.areaexpertise = areaexpertise;
    }
       
    @Override
    public String toString() {
        return "projetojpa.NonTeachingStaff[ id=" + this.getId() + " ]";
    }
    
}
