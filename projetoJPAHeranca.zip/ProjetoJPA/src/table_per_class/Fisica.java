/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package table_per_class;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 *
 * @author 04969520054
 */
@Entity
public class Fisica extends Pessoa implements Serializable {

    private String cpf;

    public Fisica() {
    }

    public Fisica(Long id, String nome, String cpf) {
        super(id, nome);
        this.cpf = cpf;
    }

    public String getCnpj() {
        return cpf;
    }

    public void setCnpj(String cnpj) {
        this.cpf = cnpj;
    }
    
    @Override
    public String toString() {
        return "table_per_class.Fisica[ id=" + this.getId() + " ]";
    }
    
}
