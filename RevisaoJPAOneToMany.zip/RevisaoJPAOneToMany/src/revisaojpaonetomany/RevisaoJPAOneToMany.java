/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package revisaojpaonetomany;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author 04969520054
 */
public class RevisaoJPAOneToMany {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        criarPedido();
    }
    
    static void criarTurma(){
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("RevisaoJPAOneToManyPU");
        EntityManager em = emf.createEntityManager();
        
        Aluno a1 = new Aluno();
        a1.setNome("Maria");
        a1.setMatricula("123865");
        
        Aluno a2 = new Aluno();
        a1.setNome("João");
        a1.setMatricula("2547683");
        
        ArrayList<Aluno> alunos = new ArrayList<Aluno>();
        alunos.add(a1);
        alunos.add(a2);
        
        Turma t = new Turma();
        t.setNome("35PROGII");
        t.setAlunos(alunos);                
        
        em.getTransaction().begin();
        em.persist(a1);
        em.persist(a2);
        em.persist(t);
        em.getTransaction().commit();
    }
    
    static void criarPedido(){
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("RevisaoJPAOneToManyPU");
        EntityManager em = emf.createEntityManager();
        
        Cliente c = new Cliente();
        c.setNome("Lucas");
        c.setCpf("456.695.889-87");
        
        Produto p = new Produto();
        p.setDescricao("Arroz");
        p.setPreco(25.69);
        
        Produto p1 = new Produto();
        p1.setDescricao("Feijão");
        p1.setPreco(32.99);
        
        ArrayList<Produto> prods = new ArrayList<Produto>();
        prods.add(p);
        prods.add(p1);
        
        Pedido pedido = new Pedido();
        pedido.setTotal(100.99);
        pedido.setProdutos(prods);
        pedido.setCliente(c);
        
        em.getTransaction().begin();
        em.persist(c);
        em.persist(p);
        em.persist(p1);
        em.persist(pedido);
        em.getTransaction().commit();        
    }
    
}
